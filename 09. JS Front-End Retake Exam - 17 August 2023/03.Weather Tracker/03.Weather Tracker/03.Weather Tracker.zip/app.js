const API_URL = "http://localhost:3030/jsonstore/tasks/";

const loadHistoryBtn = document.getElementById("load-history");
const addWeatherBtn = document.getElementById("add-weather");
const editWeatherBtn = document.getElementById("edit-weather");
const list = document.getElementById("list");
const inputLocation = document.getElementById("location");
const inputTemperature = document.getElementById("temperature");
const inputDate = document.getElementById("date");

let tempId;

async function getTasks() {
    const response = await fetch(API_URL);
    const data = await response.json();

    list.innerHTML = '';

    for (const [id, { location, temperature, date, _id }] of Object.entries(data)) {
        list.innerHTML += `
                    <div class="container" id="${_id}">
                        <h2>${location}</h2>
                        <h3>${date}</h3>
                        <h3 id="celsius">${temperature}</h3>
                        <div id="buttons-container">  
                            <button class="change-btn">Change</button>
                            <button class="delete-btn">Delete</button>
                        </div>                        
                    </div>`;
    }
}

loadHistoryBtn.addEventListener("click", getTasks);

addWeatherBtn.addEventListener("click", async e => {
    e.preventDefault();

    if (inputLocation.value !== '' && inputTemperature.value !== '' && inputDate.value !== '') {
        await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ location: inputLocation.value, temperature: inputTemperature.value, date: inputDate.value })
        });

        inputLocation.value = '';
        inputTemperature.value = '';
        inputDate.value = '';
        await getTasks();
    }
});

list.addEventListener("click", async e => {
    if (e.target.classList.contains("change-btn")) {
        const container = e.target.parentElement.parentElement;
        const h2Location = container.querySelector("h2").textContent;
        const [h3Date, h3Temperature] = container.querySelectorAll("h3");

        tempId = container.id;
        inputLocation.value = h2Location;
        inputTemperature.value = h3Temperature.textContent;
        inputDate.value = h3Date.textContent;
        addWeatherBtn.disabled = true;
        editWeatherBtn.disabled = false;
        container.remove();
    } else if (e.target.classList.contains("delete-btn")) {
        const container = e.target.parentElement.parentElement;

        tempId = container.id;
        await fetch(`${API_URL}${tempId}`, {
            method: "DELETE",
            headers: { "Content-Type": "application/json" }
        });
        tempId = '';
        await getTasks();
    }
});

editWeatherBtn.addEventListener("click", async e => {
    e.preventDefault();

    if (inputLocation.value !== '' && inputTemperature.value !== '' && inputDate.value !== '') {
        await fetch(`${API_URL}${tempId}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ location: inputLocation.value, temperature: inputTemperature.value, date: inputDate.value, _id: tempId })
        });

        inputLocation.value = '';
        inputTemperature.value = '';
        inputDate.value = '';
        addWeatherBtn.disabled = false;
        editWeatherBtn.disabled = true;
        await getTasks();
    }
});